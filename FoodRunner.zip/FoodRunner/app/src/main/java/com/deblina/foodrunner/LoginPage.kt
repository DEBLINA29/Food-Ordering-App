package com.deblina.foodrunner

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class LoginPage : AppCompatActivity() , View.OnClickListener {
    override fun onClick(p0: View?) {
        TODO("Not yet implemented")
    }

    lateinit var imgLogo : ImageView
    lateinit var etMobileNumber : EditText
    lateinit var etPassword : EditText
    lateinit var btnLogIn : Button
    lateinit var txtForgotPassword : TextView
    lateinit var txtSignUp : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        title = "Log In"

        imgLogo = findViewById(R.id.imgLogo)
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)
        btnLogIn = findViewById(R.id.btnLogIn)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtSignUp = findViewById(R.id.txtSignUp)

        btnLogIn.setOnClickListener {
            Toast.makeText(
                this@LoginPage,
                "successfully logged in",
                Toast.LENGTH_SHORT
            ).show()

            val intent = Intent(this@LoginPage, AfterLogin::class.java)
            startActivity(intent)
        }

        txtForgotPassword.setOnClickListener {
            Toast.makeText(
                this@LoginPage,
                "reset credentials",
                Toast.LENGTH_SHORT
            ).show()

            val intent1 = Intent(this@LoginPage, ForgotPassword::class.java)
            startActivity(intent1)
        }

        txtSignUp.setOnClickListener {
            Toast.makeText(
                this@LoginPage,
                "register yourself",
                Toast.LENGTH_SHORT
            ).show()

            val intent2 = Intent(this@LoginPage, RegistrationPage::class.java)
            startActivity(intent2)
        }
    }
}