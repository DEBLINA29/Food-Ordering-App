package com.deblina.foodrunner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AfterRegistration : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_after_registration)
    }
}