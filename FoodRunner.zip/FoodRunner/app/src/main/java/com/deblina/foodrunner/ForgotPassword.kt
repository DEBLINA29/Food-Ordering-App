package com.deblina.foodrunner

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class ForgotPassword : AppCompatActivity(), View.OnClickListener {
    override fun onClick(p0: View?) {
        TODO("Not yet implemented")
    }

    lateinit var imgLogo : ImageView
    lateinit var txtWrite : TextView
    lateinit var etMobileNumber : EditText
    lateinit var etPassword : EditText
    lateinit var btnLogIn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        title = "Forgot Password"

        imgLogo = findViewById(R.id.imgLogo)
        txtWrite = findViewById(R.id.txtWrite)
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)
        btnLogIn = findViewById(R.id.btnLogIn)

        btnLogIn.setOnClickListener {
            Toast.makeText(
                this@ForgotPassword,
                "success",
                Toast.LENGTH_SHORT
            ).show()

            val intentF = Intent(this@ForgotPassword, AfterForgotPassword::class.java)
            startActivity(intentF)

        }
    }
}