package com.deblina.foodrunner

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class RegistrationPage : AppCompatActivity(), View.OnClickListener {
    override fun onClick(p0: View?) {
        TODO("Not yet implemented")
    }

    lateinit var txtRegisterYourself : TextView
    lateinit var etName : EditText
    lateinit var etEmail : EditText
    lateinit var etMobileNumber : EditText
    lateinit var etDeliveryAddress : EditText
    lateinit var etPassword : EditText
    lateinit var etConfirmPassword : EditText
    lateinit var btnRegister : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration_page)

        title = "Register Yourself"

        txtRegisterYourself = findViewById(R.id.txtRegisterYourself)
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etDeliveryAddress = findViewById(R.id.etDeliveryAddress)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)


        btnRegister.setOnClickListener {
            Toast.makeText(
                this@RegistrationPage,
                "successfully Registered",
                Toast.LENGTH_SHORT
            ).show()

            val intent = Intent(this@RegistrationPage, AfterRegistration::class.java)
            startActivity(intent)
        }
    }
}