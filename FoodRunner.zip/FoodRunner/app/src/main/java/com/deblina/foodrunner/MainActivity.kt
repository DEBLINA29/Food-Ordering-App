package com.deblina.foodrunner

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private val splashTimeOut: Long = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        /*Handler().postDelayed({
            val startAct = Intent(this@MainActivity, LoginPage::class.java)
            startActivity(startAct)
        }, 2000)*/

        /*CoroutineScope(Dispatchers.Main).launch {
            delay(splashTimeOut)
            val startAct = Intent(this@MainActivity, LoginPage::class.java)
            startActivity(startAct)
            finish()*/

        Handler(Looper.getMainLooper()).postDelayed({
            val startAct = Intent(this@MainActivity, LoginPage::class.java)
            startActivity(startAct)
            finish()
        }, splashTimeOut)
    }
}
